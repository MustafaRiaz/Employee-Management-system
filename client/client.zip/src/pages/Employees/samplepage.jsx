export const SamplePage = () => {
    return(
        <div className="bg-slate-600 text-4xl text-purple-700 font-bold">
            hello World!
        </div>
    )
}