import { ResetEmailConfirmaction } from "../../components/common/reset-email-confirm.jsx"
export const ResetMailConfirmPage = () => {
    return (
        <ResetEmailConfirmaction redirectpath={"/auth/HR/login"} />
    ) 
}