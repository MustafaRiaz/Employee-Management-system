export const ResetEmailVerification = () => {
    return(
        <div>
            this is the verification email page
        </div>
    )
}